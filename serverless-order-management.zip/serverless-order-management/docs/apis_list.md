# APIs List

| API Name | HTTP Method | API URL | Sample Input | Sample Output | Notes |
|----------|-------------|---------|--------------|---------------|-------|
| **Create Order** | POST | `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders` | ```json
{
  "price": 599.99,
  "description": "MacBook Pro 16-inch"
}
``` | ```json
{
  "message": "Order created successfully",
  "order": {
    "orderId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "creationDate": "2026-01-12T10:30:45.123456",
    "price": 599.99,
    "description": "MacBook Pro 16-inch"
  }
}
``` | Creates a new order with auto-generated orderId and timestamp |
| **Get All Orders** | GET | `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders` | No body required | ```json
{
  "orders": [
    {
      "orderId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
      "creationDate": "2026-01-12T10:30:45.123456",
      "price": 599.99,
      "description": "MacBook Pro 16-inch",
      "lastModifiedDate": "2026-01-12T10:30:45.123456"
    },
    {
      "orderId": "b2c3d4e5-f6g7-8901-bcde-fg2345678901",
      "creationDate": "2026-01-12T11:15:30.654321",
      "price": 299.99,
      "description": "AirPods Pro"
    }
  ]
}
``` | Returns all orders sorted by creation date |
| **Get Specific Order** | GET | `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders/{orderId}` | URL: `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders/a1b2c3d4-e5f6-7890-abcd-ef1234567890` | ```json
{
  "orderId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "creationDate": "2026-01-12T10:30:45.123456",
  "price": 599.99,
  "description": "MacBook Pro 16-inch",
  "lastModifiedDate": "2026-01-12T10:30:45.123456"
}
``` | Replace {orderId} with actual order ID |
| **Update Order** | PUT | `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders/{orderId}` | URL: `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders/a1b2c3d4-e5f6-7890-abcd-ef1234567890`<br><br>Body:
```json
{
  "price": 549.99,
  "description": "MacBook Pro 16-inch - Sale!"
}
``` | ```json
{
  "message": "Order updated successfully",
  "order": {
    "orderId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "creationDate": "2026-01-12T10:30:45.123456",
    "price": 549.99,
    "description": "MacBook Pro 16-inch - Sale!",
    "lastModifiedDate": "2026-01-12T12:00:00.000000"
  }
}
``` | Updates price and/or description. LastModifiedDate is automatically updated |
| **Delete Order** | DELETE | `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders/{orderId}` | URL: `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders/a1b2c3d4-e5f6-7890-abcd-ef1234567890` | ```json
{
  "message": "Order deleted successfully",
  "deletedOrder": {
    "orderId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "creationDate": "2026-01-12T10:30:45.123456",
    "price": 549.99,
    "description": "MacBook Pro 16-inch - Sale!"
  }
}
``` | Triggers asynchronous backup to S3 and email notification. Response is immediate. |
| **Subscribe to Notifications** | POST | `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/notifications/subscribe` | ```json
{
  "email": "user@example.com"
}
``` | ```json
{
  "message": "Subscription request sent. Please check your email to confirm."
}
``` | User must confirm subscription via email link sent by SNS |
| **Unsubscribe from Notifications** | POST | `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/notifications/unsubscribe` | ```json
{
  "email": "user@example.com"
}
``` | ```json
{
  "message": "Successfully unsubscribed from notifications"
}
``` | Removes email from SNS topic subscriptions |
| **Generate PDF Report** | GET | `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/reports` | No body required | ```json
{
  "message": "PDF report generated successfully",
  "pdfUrl": "https://orders-backup-nofar-2024.s3.amazonaws.com/reports/deleted_orders_report_20260112-120000.pdf"
}
``` | Generates PDF from all deleted order TXT backups in S3. Returns presigned URL valid for 1 hour. |
| **Analyze Order Image (Freestyle)** | POST | `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders/{orderId}/analyze-image` | URL: `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders/bc0379f9-39e4-46f4-a7c4-5cdc9efbb03d/analyze-image`<br><br>Body:
```json
{
  "image": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAk...base64_encoded_image..."
}
``` | ```json
{
  "message": "Image analyzed successfully",
  "orderId": "bc0379f9-39e4-46f4-a7c4-5cdc9efbb03d",
  "imageUrl": "https://orders-backup-nofar-2024.s3.amazonaws.com/order-images/bc0379f9-39e4-46f4-a7c4-5cdc9efbb03d_20260112-173913.jpg",
  "analysis": {
    "labels": [
      {
        "name": "Electronics",
        "confidence": 98.95
      },
      {
        "name": "Computer",
        "confidence": 95.42
      }
    ],
    "detectedText": [
      "MacBook",
      "Pro"
    ]
  }
}
``` | Uses Amazon Rekognition to detect objects and text in images. Image must be base64 encoded (without data:image prefix). Updates order in DynamoDB with analysis results. |

## Error Responses:

All APIs return appropriate HTTP status codes and error messages:

### 400 Bad Request:
```json
{
  "error": "Missing required fields: price and description"
}
```

### 404 Not Found:
```json
{
  "error": "Order not found"
}
```

### 500 Internal Server Error:
```json
{
  "error": "Internal server error: <error details>"
}
```

## Important Notes:

1. **CORS:** All endpoints have CORS enabled with `Access-Control-Allow-Origin: *`

2. **Content-Type:** All POST/PUT requests require `Content-Type: application/json` header

3. **Asynchronous Operations:** 
   - DELETE /orders triggers NotifyDeletion and BackupOrder asynchronously
   - The API response is immediate; email and backup happen in the background

4. **Image Format:** 
   - For analyze-image endpoint, images must be base64 encoded
   - Remove any data URI prefix (e.g., `data:image/jpeg;base64,`)
   - Supported formats: JPG, JPEG, PNG

5. **PDF Report:** 
   - Requires at least one deleted order backup in S3
   - PDF URL is presigned and expires after 1 hour
   - PDF is stored permanently in S3 reports/ folder

6. **Email Notifications:**
   - Sent automatically when orders are deleted
   - Only to confirmed subscribers
   - Includes full deleted order details

## Testing with Postman:

All APIs have been tested successfully with Postman. Screenshots are available showing:
- Successful 200/201 responses
- Proper error handling (400, 404, 500)
- Complete request/response cycles
- Email notifications received
- S3 backups created
- PDF reports generated
- Rekognition image analysis working
