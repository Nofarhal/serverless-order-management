# AWS Architecture Diagram - Event-Driven Serverless Order Management System

## System Architecture Overview

This is a fully serverless, event-driven architecture built on AWS. The system uses API Gateway as the entry point, Lambda for compute, DynamoDB for data persistence, SNS for notifications, S3 for storage, and Rekognition for AI image analysis.

## Architecture Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          CLIENT LAYER                                    │
│                                                                          │
│   ┌──────────────────┐              ┌─────────────────┐                │
│   │   Web Client     │              │    Postman      │                │
│   │   (HTML/CSS/JS)  │              │   API Testing   │                │
│   └────────┬─────────┘              └────────┬────────┘                │
│            │                                  │                          │
│            └──────────────┬───────────────────┘                          │
│                           │                                              │
└───────────────────────────┼──────────────────────────────────────────────┘
                            │ HTTPS
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         API GATEWAY LAYER                                │
│                                                                          │
│   ┌──────────────────────────────────────────────────────────────┐     │
│   │            OrderManagementAPI (REST API)                     │     │
│   │                                                              │     │
│   │  ┌─────────────┐  ┌──────────────┐  ┌───────────────┐     │     │
│   │  │  /orders    │  │ /notifications│  │   /reports    │     │     │
│   │  │  POST, GET  │  │   POST        │  │     GET       │     │     │
│   │  └─────────────┘  └──────────────┘  └───────────────┘     │     │
│   │                                                              │     │
│   │  ┌───────────────────────────────────────────────┐         │     │
│   │  │  /orders/{orderId}                            │         │     │
│   │  │  GET, PUT, DELETE                             │         │     │
│   │  │                                               │         │     │
│   │  │  ┌────────────────────────────────┐          │         │     │
│   │  │  │  /analyze-image (Freestyle)    │          │         │     │
│   │  │  │  POST                          │          │         │     │
│   │  │  └────────────────────────────────┘          │         │     │
│   │  └───────────────────────────────────────────────┘         │     │
│   └──────────────────────────────────────────────────────────────┘     │
└───────────────────────────┬──────────────────────────────────────────────┘
                            │ Lambda Proxy Integration
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        COMPUTE LAYER (Lambda)                            │
│                                                                          │
│  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐           │
│  │  CreateOrder   │  │ GetAllOrders   │  │   GetOrder     │           │
│  │  Python 3.12   │  │  Python 3.12   │  │  Python 3.12   │           │
│  └───────┬────────┘  └───────┬────────┘  └───────┬────────┘           │
│          │                    │                    │                     │
│          └────────────────────┼────────────────────┘                     │
│                               │                                          │
│  ┌────────────────┐  ┌────────────────┐  ┌────────────────────┐       │
│  │  UpdateOrder   │  │  DeleteOrder   │  │ SubscribeEmail     │       │
│  │  Python 3.12   │  │  Python 3.12   │  │  Python 3.12       │       │
│  └───────┬────────┘  └───────┬────────┘  └───────┬────────────┘       │
│          │                    │                    │                     │
│          │                    │ Direct Invocation  │                     │
│          │          ┌─────────┼─────────┐          │                     │
│          │          │         │         │          │                     │
│          │          ▼         ▼         ▼          │                     │
│          │   ┌──────────┐ ┌──────────┐            │                     │
│          │   │  Notify  │ │  Backup  │            │                     │
│          │   │ Deletion │ │  Order   │            │                     │
│          │   │ Py 3.12  │ │ Py 3.12  │            │                     │
│          │   └────┬─────┘ └────┬─────┘            │                     │
│          │        │            │                   │                     │
│  ┌────────────────┼────────────┼───────────────────┼──────────┐        │
│  │ UnsubscribeEmail│           │                   │          │        │
│  │  Python 3.12   │            │                   │          │        │
│  └───────┬────────┘            │                   │          │        │
│          │                      │                   │          │        │
│  ┌───────────────────┐  ┌──────────────────┐               │        │
│  │ GeneratePDFReport │  │ AnalyzeOrderImage│               │        │
│  │   Python 3.12     │  │   Python 3.12    │  (Freestyle) │        │
│  │   + Layer         │  │   + Rekognition  │               │        │
│  └────────┬──────────┘  └────────┬─────────┘               │        │
│           │                       │                          │        │
└───────────┼───────────────────────┼──────────────────────────┼────────┘
            │                       │                          │
            ▼                       ▼                          ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                      DATA & STORAGE LAYER                                │
│                                                                          │
│  ┌──────────────────────────────────────────────────────────────┐      │
│  │                      DynamoDB                                 │      │
│  │  ┌────────────────────────────────────────────────┐          │      │
│  │  │  orders (Table)                                │          │      │
│  │  │  • orderId (Partition Key)                     │          │      │
│  │  │  • creationDate (Sort Key)                     │          │      │
│  │  │  • price, description, lastModifiedDate        │          │      │
│  │  │  • imageUrl, imageLabels, imageText (Optional) │          │      │
│  │  └────────────────────────────────────────────────┘          │      │
│  └──────────────────────────────────────────────────────────────┘      │
│                                                                          │
│  ┌──────────────────────────────────────────────────────────────┐      │
│  │                         S3 Bucket                             │      │
│  │         orders-backup-nofar-2024                             │      │
│  │                                                              │      │
│  │  ┌─────────────────┐  ┌─────────────┐  ┌───────────────┐  │      │
│  │  │ deleted_orders/ │  │  reports/   │  │ order-images/ │  │      │
│  │  │  (TXT backups)  │  │  (PDFs)     │  │  (JPG/PNG)    │  │      │
│  │  └─────────────────┘  └─────────────┘  └───────────────┘  │      │
│  └──────────────────────────────────────────────────────────────┘      │
│                                                                          │
│  ┌──────────────────────────────────────────────────────────────┐      │
│  │                          SNS                                  │      │
│  │  ┌────────────────────────────────────────────────┐          │      │
│  │  │  OrderDeletionNotifications (Topic)            │          │      │
│  │  │  • Email subscriptions                         │          │      │
│  │  │  • Async notification delivery                 │          │      │
│  │  └────────────────────────────────────────────────┘          │      │
│  └──────────────────────────────────────────────────────────────┘      │
│                                                                          │
│  ┌──────────────────────────────────────────────────────────────┐      │
│  │                     Rekognition                               │      │
│  │  • detect_labels (Object detection)                          │      │
│  │  • detect_text (OCR)                                         │      │
│  │  • ML-powered image analysis                                 │      │
│  └──────────────────────────────────────────────────────────────┘      │
└──────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                      MONITORING & LOGGING                                │
│                                                                          │
│                        CloudWatch Logs                                   │
│              (Automatic logging for all Lambda functions)               │
└──────────────────────────────────────────────────────────────────────────┘
```

## Component Integration Explanation

### 1. Client Layer
**Web Client / Postman** → Makes HTTPS requests to API Gateway
- Web client built with HTML/CSS/JavaScript
- Supports all CRUD operations
- Includes Rekognition image upload and analysis
- Postman used for API testing

### 2. API Gateway (Entry Point)
**REST API** → Routes requests to appropriate Lambda functions
- Single REST API: OrderManagementAPI
- 9 total endpoints across 4 resources
- CORS enabled for web client support
- Lambda Proxy Integration for full request context

### 3. Compute Layer (Lambda Functions)

#### CRUD Operations:
- **CreateOrder** → Validates input, generates orderId, writes to DynamoDB
- **GetAllOrders** → Scans DynamoDB, returns all orders sorted
- **GetOrder** → Queries specific order by orderId
- **UpdateOrder** → Updates order fields, sets lastModifiedDate
- **DeleteOrder** → Deletes from DynamoDB, triggers async operations

#### Asynchronous Event Processing:
**DeleteOrder** invokes directly (not via EventBridge due to Learner Lab restrictions):
- **NotifyDeletion** → Formats and sends email via SNS
- **BackupOrder** → Creates TXT file in S3 deleted_orders/ folder

This architecture ensures:
- ✅ Immediate API response (non-blocking)
- ✅ Async notification delivery
- ✅ Async backup creation
- ✅ No coupling between operations

#### Notification Management:
- **SubscribeEmail** → Adds email to SNS topic
- **UnsubscribeEmail** → Removes email from SNS topic

#### Reporting:
- **GeneratePDFReport** → Reads all TXT backups, generates PDF with reportlab
  - Uses custom Lambda Layer: reportlab-layer-py312
  - Built with Docker for Python 3.12 compatibility
  - Returns presigned S3 URL

#### Freestyle Enhancement (Rekognition):
- **AnalyzeOrderImage** → Analyzes product images with AI
  - Uploads image to S3 order-images/
  - Calls Rekognition detect_labels (objects)
  - Calls Rekognition detect_text (OCR)
  - Updates order in DynamoDB with results

### 4. Data & Storage Layer

#### DynamoDB (orders table):
- **Purpose:** Persistent storage for all order data
- **Design:**
  - Partition Key: orderId (UUID)
  - Sort Key: creationDate (ISO timestamp)
- **Attributes:** price, description, lastModifiedDate, imageUrl, imageLabels, imageText
- **Why:** Serverless, auto-scaling, predictable performance

#### S3 Bucket (orders-backup-nofar-2024):
**Three folders for different purposes:**
1. **deleted_orders/** → TXT backups of deleted orders
   - Created by BackupOrder Lambda
   - Format: {orderId}_{timestamp}.txt
   
2. **reports/** → Generated PDF reports
   - Created by GeneratePDFReport Lambda
   - Contains summary of all deleted orders
   
3. **order-images/** → Uploaded product images
   - Created by AnalyzeOrderImage Lambda
   - Format: {orderId}_{timestamp}.jpg

**Why S3:** Durable, scalable, cost-effective object storage

#### SNS (OrderDeletionNotifications):
- **Purpose:** Pub/Sub messaging for email notifications
- **Flow:** DeleteOrder → NotifyDeletion → SNS → Email subscribers
- **Why:** Decouples notification from deletion, supports multiple subscribers

#### Rekognition:
- **Purpose:** AI-powered image analysis (Freestyle enhancement)
- **Capabilities:**
  - Object detection (labels with confidence scores)
  - Text extraction (OCR)
- **Integration:** Called by AnalyzeOrderImage Lambda
- **Why:** Adds ML/AI capabilities without managing infrastructure

### 5. Monitoring & Logging

#### CloudWatch Logs:
- Automatic log group for each Lambda function
- Captures all print statements and errors
- Used for debugging and monitoring
- Permanent retention

## Key Architectural Decisions

### 1. Direct Lambda Invocation vs EventBridge
**Decision:** Use direct Lambda invocation for async operations
**Reason:** Learner Lab IAM restrictions prevent EventBridge Rule creation
**Implementation:** DeleteOrder directly invokes NotifyDeletion and BackupOrder
**Benefit:** Achieves same async behavior without requiring additional IAM permissions

### 2. DynamoDB Key Design
**Partition Key:** orderId (UUID)
**Sort Key:** creationDate (timestamp)
**Reason:** 
- orderId ensures unique identification
- creationDate enables sorting and range queries
- Composite key supports efficient queries

### 3. Lambda Layer for PDF Generation
**Decision:** Build custom Layer with Docker
**Reason:** reportlab requires binary dependencies that must match Lambda runtime
**Implementation:** Docker container with Python 3.12 base image
**Benefit:** Ensures compatibility with Lambda execution environment

### 4. Rekognition for Freestyle
**Decision:** Add AI image analysis capability
**Reason:** 
- Demonstrates advanced AWS service integration
- Adds real business value (product categorization)
- Showcases ML/AI without training models
- Easy to demonstrate and test

### 5. Serverless Architecture
**Decision:** Pure serverless (no EC2, no containers)
**Reason:**
- Auto-scaling
- Pay-per-use pricing
- No server management
- High availability built-in
- Perfect for event-driven workloads

## Data Flow Examples

### Creating an Order:
```
Client → API Gateway → CreateOrder Lambda → DynamoDB → Response
```

### Deleting an Order (with async operations):
```
Client → API Gateway → DeleteOrder Lambda → DynamoDB (delete)
                            ↓
                    ┌───────┴───────┐
                    ↓               ↓
            NotifyDeletion    BackupOrder
                    ↓               ↓
                   SNS             S3
                    ↓
                  Email
```

### Analyzing Product Image:
```
Client → API Gateway → AnalyzeOrderImage Lambda
                            ↓
                    ┌───────┴───────┐
                    ↓               ↓
                   S3         Rekognition
            (store image)   (analyze image)
                    ↓
                DynamoDB
             (save results)
```

## Security & Best Practices

1. **IAM Roles:** All Lambdas use LabRole with least-privilege permissions
2. **CORS:** Properly configured for web client security
3. **Input Validation:** All Lambda functions validate inputs
4. **Error Handling:** Comprehensive try-catch blocks
5. **Logging:** All operations logged to CloudWatch
6. **Async Operations:** Non-blocking architecture for better UX

## Scalability

- **DynamoDB:** Auto-scales read/write capacity
- **Lambda:** Concurrent executions scale automatically
- **API Gateway:** Handles thousands of requests per second
- **S3:** Unlimited storage capacity
- **SNS:** Delivers messages to unlimited subscribers

This architecture can handle production workloads without modification.
