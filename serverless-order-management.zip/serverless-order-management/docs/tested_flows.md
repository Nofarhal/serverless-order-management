# Tested Flows - Order Management System

## Overview
This document provides a comprehensive list of all tested flows in the Event-Driven Serverless Order Management System. Each flow has been thoroughly tested and verified to work correctly.

---

## Flow 1: Create Order
**Functionality:** Create a new order with price and description

### Steps:
1. Open Postman
2. Set method to POST
3. URL: `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders`
4. Headers: `Content-Type: application/json`
5. Body (raw JSON):
```json
{
  "price": 599.99,
  "description": "MacBook Pro 16-inch"
}
```
6. Click Send

### Expected Result:
- Status: 201 Created
- Response includes:
  - Generated orderId (UUID)
  - creationDate (ISO timestamp)
  - price (599.99)
  - description ("MacBook Pro 16-inch")

### Verification:
✅ Order created in DynamoDB
✅ Unique orderId generated
✅ Timestamp automatically set
✅ API response immediate (< 1 second)

### Screenshot Notes:
- Shows Postman request with sample input
- Shows 201 success response with order details
- Shows generated orderId and timestamp

---

## Flow 2: Get All Orders
**Functionality:** Retrieve all orders sorted by creation date

### Steps:
1. Open Postman
2. Set method to GET
3. URL: `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders`
4. No body required
5. Click Send

### Expected Result:
- Status: 200 OK
- Response contains array of all orders
- Orders sorted by creationDate (newest first)
- Each order includes: orderId, creationDate, price, description, lastModifiedDate

### Verification:
✅ All orders returned from DynamoDB
✅ Proper sorting by creation date
✅ All fields present
✅ Fast response time

### Screenshot Notes:
- Shows GET request
- Shows response with multiple orders
- Shows proper date sorting

---

## Flow 3: Get Specific Order
**Functionality:** Retrieve a single order by ID

### Steps:
1. Copy an orderId from previous flow
2. Open Postman
3. Set method to GET
4. URL: `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders/{orderId}`
5. Replace {orderId} with actual ID
6. Click Send

### Expected Result:
- Status: 200 OK
- Response contains single order with all details
- If order doesn't exist: 404 Not Found

### Verification:
✅ Correct order retrieved
✅ All fields accurate
✅ 404 for non-existent orders

### Screenshot Notes:
- Shows GET request with orderId in URL
- Shows single order response
- Optional: Shows 404 for invalid ID

---

## Flow 4: Update Order
**Functionality:** Update price and/or description of existing order

### Steps:
1. Open Postman
2. Set method to PUT
3. URL: `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders/{orderId}`
4. Headers: `Content-Type: application/json`
5. Body (raw JSON):
```json
{
  "price": 549.99,
  "description": "MacBook Pro 16-inch - On Sale!"
}
```
6. Click Send

### Expected Result:
- Status: 200 OK
- Response shows updated order
- lastModifiedDate updated automatically
- creationDate unchanged

### Verification:
✅ Order updated in DynamoDB
✅ lastModifiedDate automatically set
✅ Original creationDate preserved
✅ Price and description changed

### Screenshot Notes:
- Shows PUT request with updated values
- Shows response with new lastModifiedDate
- Shows both price and description updated

---

## Flow 5: Delete Order (with Async Operations)
**Functionality:** Delete order and trigger asynchronous backup and notification

### Steps:
1. Subscribe to notifications first (see Flow 6)
2. Open Postman
3. Set method to DELETE
4. URL: `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders/{orderId}`
5. Click Send
6. Check email inbox
7. Check S3 bucket: deleted_orders/ folder

### Expected Result:
- Status: 200 OK
- Response immediate (< 1 second)
- Response includes deleted order details
- Email notification received (within 30 seconds)
- TXT backup created in S3 (within 30 seconds)

### Verification:
✅ Order deleted from DynamoDB
✅ API response immediate (non-blocking)
✅ Email notification sent asynchronously
✅ S3 backup created asynchronously
✅ Email contains order details
✅ TXT file contains order details

### Async Architecture Verification:
- DeleteOrder Lambda completes immediately
- NotifyDeletion Lambda invoked asynchronously
- BackupOrder Lambda invoked asynchronously
- No coupling between operations

### Screenshot Notes:
- Shows DELETE request
- Shows immediate 200 response
- Shows email notification received
- Shows S3 bucket with TXT backup file
- Shows TXT file contents

---

## Flow 6: Subscribe to Notifications
**Functionality:** Register email to receive deletion notifications

### Steps:
1. Open Postman
2. Set method to POST
3. URL: `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/notifications/subscribe`
4. Headers: `Content-Type: application/json`
5. Body (raw JSON):
```json
{
  "email": "your-email@example.com"
}
```
6. Click Send
7. Check email inbox
8. Click confirmation link in email

### Expected Result:
- Status: 200 OK
- Message: "Subscription request sent. Please check your email to confirm."
- Confirmation email received from AWS SNS
- After clicking link: subscription confirmed

### Verification:
✅ Subscription created in SNS
✅ Confirmation email sent
✅ User can confirm subscription
✅ Subscription active in SNS topic

### Screenshot Notes:
- Shows POST request with email
- Shows 200 response
- Shows SNS confirmation email
- Shows confirmed subscription in SNS console

---

## Flow 7: Unsubscribe from Notifications
**Functionality:** Remove email from notification list

### Steps:
1. Open Postman
2. Set method to POST
3. URL: `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/notifications/unsubscribe`
4. Headers: `Content-Type: application/json`
5. Body (raw JSON):
```json
{
  "email": "your-email@example.com"
}
```
6. Click Send

### Expected Result:
- Status: 200 OK
- Message: "Successfully unsubscribed from notifications"
- Subscription removed from SNS

### Verification:
✅ Subscription removed from SNS topic
✅ No more notifications received
✅ Can re-subscribe later

### Screenshot Notes:
- Shows POST request with email
- Shows success response
- Shows subscription removed in SNS console

---

## Flow 8: Generate PDF Report
**Functionality:** Create PDF summary of all deleted orders

### Steps:
1. Ensure at least one order has been deleted (Flow 5)
2. Open Postman
3. Set method to GET
4. URL: `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/reports`
5. Click Send
6. Copy pdfUrl from response
7. Paste URL in browser
8. PDF downloads automatically

### Expected Result:
- Status: 200 OK
- Response includes presigned S3 URL
- URL valid for 1 hour
- PDF contains summary of all deleted orders
- PDF includes: Order ID, price, description, deletion date

### Verification:
✅ PDF generated from S3 backups
✅ All deleted orders included
✅ Proper formatting
✅ Presigned URL works
✅ PDF stored in S3 reports/ folder

### Screenshot Notes:
- Shows GET request
- Shows response with pdfUrl
- Shows PDF opened in browser
- Shows PDF content with order details

---

## Flow 9: AI Image Analysis (Freestyle Enhancement)
**Functionality:** Upload product image and analyze with Amazon Rekognition

### Steps:
1. Create an order first (Flow 1)
2. Copy the orderId
3. Prepare a product image (JPG/PNG)
4. Convert image to base64:
   - Use: https://www.base64-image.de/
   - Upload image
   - Copy base64 string (WITHOUT data:image prefix)
5. Open Postman
6. Set method to POST
7. URL: `https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod/orders/{orderId}/analyze-image`
8. Headers: `Content-Type: application/json`
9. Body (raw JSON):
```json
{
  "image": "/9j/4AAQSkZJRgABAQAA...base64_string_here..."
}
```
10. Click Send

### Expected Result:
- Status: 200 OK
- Response includes:
  - imageUrl (S3 URL where image stored)
  - analysis object with:
    - labels: Array of detected objects with confidence scores
    - detectedText: Array of text found in image (OCR)
- Image uploaded to S3 order-images/ folder
- Order updated in DynamoDB with analysis results

### Verification:
✅ Image uploaded to S3
✅ Rekognition detect_labels executed
✅ Rekognition detect_text executed
✅ Results saved in DynamoDB
✅ Labels show detected objects (e.g., "Electronics", "Computer")
✅ Text shows OCR results (e.g., "MacBook", "Pro")
✅ Confidence scores included

### Example Response:
```json
{
  "message": "Image analyzed successfully",
  "orderId": "bc0379f9-39e4-46f4-a7c4-5cdc9efbb03d",
  "imageUrl": "https://orders-backup-nofar-2024.s3.amazonaws.com/order-images/bc0379f9-39e4-46f4-a7c4-5cdc9efbb03d_20260112-173913.jpg",
  "analysis": {
    "labels": [
      {
        "name": "Electronics",
        "confidence": 98.95
      },
      {
        "name": "Computer",
        "confidence": 95.42
      },
      {
        "name": "Laptop",
        "confidence": 93.18
      }
    ],
    "detectedText": [
      "MacBook",
      "Pro",
      "16-inch"
    ]
  }
}
```

### Screenshot Notes:
- Shows POST request with base64 image (truncated)
- Shows successful response with labels and text
- Shows S3 bucket with uploaded image
- Shows DynamoDB order with imageUrl and imageLabels
- Shows web client displaying image and AI analysis

---

## Flow 10: Web Client - Complete User Journey
**Functionality:** End-to-end user experience through web interface

### Steps:
1. Open web client: https://prod.d26305dofspqvh.amplifyapp.com
2. View statistics (Total Orders, Total Value)
3. Create new order:
   - Enter price: 299.99
   - Enter description: "Wireless Headphones"
   - Click "Create Order"
4. Refresh orders list
5. Upload image for order:
   - Click "Add Image" button on order card
   - Select product image from computer
   - See preview
   - Click "Analyze Image"
   - Wait for AI analysis results
6. View AI analysis results on order card
7. Update order:
   - Click "Edit" button
   - Enter new price: 249.99
   - Enter new description: "Wireless Headphones - Sale!"
   - Confirm
8. Subscribe to notifications:
   - Enter email address
   - Click "Subscribe to Notifications"
   - Check email for confirmation
   - Confirm subscription
9. Delete order:
   - Click "Delete" button
   - Confirm deletion
   - See success message
   - Check email for deletion notification
10. Verify all operations completed successfully

### Expected Result:
- All operations work smoothly through UI
- Statistics update in real-time
- Image upload and analysis working
- AI results displayed on order cards
- Email notifications received
- Professional, responsive interface

### Verification:
✅ Web client hosted on Amplify
✅ All CRUD operations functional
✅ Image upload and analysis working
✅ Real-time statistics
✅ Responsive design
✅ Error handling and user feedback
✅ Email notifications delivered

### Screenshot Notes:
- Shows web client homepage with statistics
- Shows create order form
- Shows order card with image and AI labels
- Shows image analysis interface
- Shows email notification
- Shows responsive design on different screens

---

## Flow 11: Error Handling - Invalid Inputs
**Functionality:** System properly handles invalid inputs

### Test Cases:

#### Test 11a: Create Order - Missing Fields
**Steps:**
1. POST to /orders with empty body: `{}`
2. Expected: 400 Bad Request with error message

#### Test 11b: Create Order - Invalid Price
**Steps:**
1. POST to /orders with negative price: `{"price": -100, "description": "Test"}`
2. Expected: 400 Bad Request

#### Test 11c: Get Order - Invalid ID
**Steps:**
1. GET /orders/invalid-id-format
2. Expected: 404 Not Found

#### Test 11d: Update Order - Non-existent Order
**Steps:**
1. PUT to /orders/00000000-0000-0000-0000-000000000000
2. Expected: 404 Not Found

#### Test 11e: Image Analysis - Invalid Base64
**Steps:**
1. POST to /orders/{id}/analyze-image with invalid base64
2. Expected: 400 Bad Request or 500 with clear error

### Verification:
✅ All error cases handled gracefully
✅ Appropriate HTTP status codes returned
✅ Clear error messages provided
✅ No system crashes
✅ Logs available in CloudWatch

### Screenshot Notes:
- Shows various error responses
- Shows error messages in Postman
- Shows CloudWatch logs for errors

---

## Flow 12: Performance and Scalability
**Functionality:** System handles concurrent operations

### Steps:
1. Use Postman Collection Runner
2. Run 10 concurrent create order requests
3. Run 10 concurrent get all orders requests
4. Run 5 concurrent delete operations
5. Verify all operations complete successfully

### Expected Result:
- All requests complete successfully
- No timeout errors
- No race conditions
- Consistent data in DynamoDB
- Lambda auto-scaling handles load

### Verification:
✅ Concurrent requests handled
✅ No data corruption
✅ Lambda scaling automatic
✅ DynamoDB handling load
✅ API Gateway rate limiting working

### Screenshot Notes:
- Shows Postman Collection Runner
- Shows CloudWatch metrics
- Shows Lambda concurrent executions

---

## Summary of Test Coverage

### Core Functionality (All ✅):
1. ✅ Create Order
2. ✅ Read Orders (All)
3. ✅ Read Order (Single)
4. ✅ Update Order
5. ✅ Delete Order
6. ✅ Subscribe to Notifications
7. ✅ Unsubscribe from Notifications
8. ✅ Generate PDF Report
9. ✅ AI Image Analysis (Freestyle)

### Event-Driven Architecture (All ✅):
1. ✅ Asynchronous Notifications (Non-blocking)
2. ✅ Asynchronous Backups (Non-blocking)
3. ✅ Direct Lambda Invocation
4. ✅ SNS Email Delivery
5. ✅ S3 Object Storage

### Advanced Features (All ✅):
1. ✅ Amazon Rekognition Integration
2. ✅ PDF Generation with reportlab
3. ✅ Lambda Layers
4. ✅ Web Client on Amplify
5. ✅ CORS Configuration

### Error Handling (All ✅):
1. ✅ Invalid Inputs
2. ✅ Missing Fields
3. ✅ Non-existent Resources
4. ✅ Proper HTTP Status Codes
5. ✅ Clear Error Messages

### Performance (All ✅):
1. ✅ Fast Response Times (< 1s)
2. ✅ Concurrent Requests
3. ✅ Auto-scaling
4. ✅ Non-blocking Architecture

---

## Testing Tools Used
- **Postman:** API testing
- **Web Browser:** Web client testing
- **AWS Console:** Service verification
- **Email Client:** Notification testing
- **CloudWatch Logs:** Error tracking and debugging

---

## Notes for Reviewers

### All Flows Tested:
Every flow listed above has been thoroughly tested and verified to work correctly. Screenshots for each flow are available showing:
1. The request/action taken
2. The successful response/result
3. Verification in AWS services (DynamoDB, S3, SNS, etc.)

### Reproducibility:
All flows can be reproduced by:
1. Using the provided Postman requests
2. Following the step-by-step instructions
3. Using the provided sample inputs
4. Verifying results in AWS Console

### System Status:
- All 11 Lambda functions: ✅ Working
- All 9 API endpoints: ✅ Working
- DynamoDB table: ✅ Operational
- S3 bucket: ✅ Operational
- SNS topic: ✅ Operational
- Rekognition service: ✅ Operational
- Web client: ✅ Deployed and working

### AWS Resources:
- Region: us-east-1
- API Base URL: https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod
- S3 Bucket: orders-backup-nofar-2024
- DynamoDB Table: orders
- Web Client: https://prod.d26305dofspqvh.amplifyapp.com
