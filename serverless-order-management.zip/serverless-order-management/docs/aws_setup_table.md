# AWS Setup Table

| AWS Service | AWS Sub-service | Why did you choose this service? | What is the non-default setup? | CLI Command |
|-------------|-----------------|-----------------------------------|-------------------------------|-------------|
| **DynamoDB** | Table: `orders` | Chosen for its serverless nature, automatic scaling, and perfect fit for key-value storage of order data. Provides fast, predictable performance with seamless scalability. | **Primary Key:** orderId (String) - Partition key<br>**Sort Key:** creationDate (String)<br>**Reason:** Allows efficient querying by orderId and sorting by creation date. | `aws dynamodb describe-table --table-name orders` |
| **Lambda** | Function: `CreateOrder` | Serverless compute for creating orders. Automatically scales and only charges for actual execution time. No server management needed. | **Runtime:** Python 3.12<br>**Memory:** 128 MB<br>**Timeout:** 30 seconds<br>**Role:** LabRole | `aws lambda get-function --function-name CreateOrder` |
| **Lambda** | Function: `GetAllOrders` | Retrieves all orders from DynamoDB with sorting capability. Serverless execution ensures cost efficiency. | **Runtime:** Python 3.12<br>**Memory:** 128 MB<br>**Timeout:** 30 seconds<br>**Role:** LabRole | `aws lambda get-function --function-name GetAllOrders` |
| **Lambda** | Function: `GetOrder` | Retrieves specific order by ID. Lambda ensures fast response times with automatic scaling. | **Runtime:** Python 3.12<br>**Memory:** 128 MB<br>**Timeout:** 30 seconds<br>**Role:** LabRole | `aws lambda get-function --function-name GetOrder` |
| **Lambda** | Function: `UpdateOrder` | Updates order details in DynamoDB. Serverless architecture ensures high availability. | **Runtime:** Python 3.12<br>**Memory:** 128 MB<br>**Timeout:** 30 seconds<br>**Role:** LabRole | `aws lambda get-function --function-name UpdateOrder` |
| **Lambda** | Function: `DeleteOrder` | Deletes orders and triggers asynchronous backup and notification processes through direct Lambda invocation. | **Runtime:** Python 3.12<br>**Memory:** 128 MB<br>**Timeout:** 30 seconds<br>**Role:** LabRole<br>**Custom:** Direct Lambda invocation to NotifyDeletion and BackupOrder | `aws lambda get-function --function-name DeleteOrder` |
| **Lambda** | Function: `SubscribeEmail` | Subscribes email addresses to SNS topic for notifications. Serverless integration with SNS. | **Runtime:** Python 3.12<br>**Memory:** 128 MB<br>**Timeout:** 30 seconds<br>**Role:** LabRole | `aws lambda get-function --function-name SubscribeEmail` |
| **Lambda** | Function: `UnsubscribeEmail` | Removes email subscriptions from SNS. Provides user control over notifications. | **Runtime:** Python 3.12<br>**Memory:** 128 MB<br>**Timeout:** 30 seconds<br>**Role:** LabRole | `aws lambda get-function --function-name UnsubscribeEmail` |
| **Lambda** | Function: `NotifyDeletion` | Sends email notifications when orders are deleted. Invoked asynchronously to not block deletion process. | **Runtime:** Python 3.12<br>**Memory:** 128 MB<br>**Timeout:** 30 seconds<br>**Role:** LabRole<br>**Custom:** Invoked directly by DeleteOrder Lambda | `aws lambda get-function --function-name NotifyDeletion` |
| **Lambda** | Function: `BackupOrder` | Creates TXT backup of deleted orders in S3. Runs asynchronously to ensure deletion isn't delayed. | **Runtime:** Python 3.12<br>**Memory:** 128 MB<br>**Timeout:** 30 seconds<br>**Role:** LabRole<br>**Custom:** Invoked directly by DeleteOrder Lambda | `aws lambda get-function --function-name BackupOrder` |
| **Lambda** | Function: `GeneratePDFReport` | Generates PDF reports from all deleted order backups in S3 using reportlab library. | **Runtime:** Python 3.12<br>**Memory:** 512 MB<br>**Timeout:** 60 seconds<br>**Role:** LabRole<br>**Layer:** reportlab-layer-py312 (custom built with Docker for Python 3.12 compatibility) | `aws lambda get-function --function-name GeneratePDFReport` |
| **Lambda** | Function: `AnalyzeOrderImage` | Analyzes product images using Amazon Rekognition for label detection and OCR. Freestyle enhancement. | **Runtime:** Python 3.12<br>**Memory:** 256 MB<br>**Timeout:** 60 seconds<br>**Role:** LabRole<br>**Custom:** Integrates with Rekognition and stores results in DynamoDB | `aws lambda get-function --function-name AnalyzeOrderImage` |
| **API Gateway** | API: `OrderManagementAPI` | Provides REST API interface for all operations. Chosen for seamless Lambda integration and built-in features like CORS, throttling, and caching. | **Type:** REST API<br>**Stage:** prod<br>**CORS:** Enabled on all resources<br>**Endpoints:** 9 total<br>**Integration:** Lambda Proxy Integration enabled | `aws apigateway get-rest-apis` |
| **API Gateway** | Resource: `/orders` | Main resource for order operations. Supports POST and GET methods. | **Methods:** POST (CreateOrder), GET (GetAllOrders)<br>**CORS:** Enabled | `aws apigateway get-resources --rest-api-id 6kav3jqnbg` |
| **API Gateway** | Resource: `/orders/{orderId}` | Resource for single order operations with path parameter. | **Methods:** GET (GetOrder), PUT (UpdateOrder), DELETE (DeleteOrder)<br>**CORS:** Enabled | `aws apigateway get-resources --rest-api-id 6kav3jqnbg` |
| **API Gateway** | Resource: `/orders/{orderId}/analyze-image` | Endpoint for AI image analysis using Rekognition. Freestyle enhancement. | **Method:** POST (AnalyzeOrderImage)<br>**CORS:** Enabled<br>**Lambda Proxy:** Enabled | `aws apigateway get-resources --rest-api-id 6kav3jqnbg` |
| **API Gateway** | Resource: `/notifications/subscribe` | Endpoint for email subscription to notifications. | **Method:** POST (SubscribeEmail)<br>**CORS:** Enabled | `aws apigateway get-resources --rest-api-id 6kav3jqnbg` |
| **API Gateway** | Resource: `/notifications/unsubscribe` | Endpoint for unsubscribing from notifications. | **Method:** POST (UnsubscribeEmail)<br>**CORS:** Enabled | `aws apigateway get-resources --rest-api-id 6kav3jqnbg` |
| **API Gateway** | Resource: `/reports` | Endpoint for generating PDF reports of deleted orders. | **Method:** GET (GeneratePDFReport)<br>**CORS:** Enabled | `aws apigateway get-resources --rest-api-id 6kav3jqnbg` |
| **SNS** | Topic: `OrderDeletionNotifications` | Chosen for pub/sub messaging pattern. Allows multiple email subscribers to receive notifications asynchronously when orders are deleted. | **Type:** Standard topic<br>**Protocol:** Email<br>**Usage:** Asynchronous notification delivery | `aws sns list-topics` |
| **S3** | Bucket: `orders-backup-nofar-2024` | Object storage for deleted order backups and generated PDF reports. Chosen for durability, scalability, and cost-effectiveness. | **Folders:**<br>- `deleted_orders/` (TXT backups)<br>- `reports/` (PDF reports)<br>- `order-images/` (Rekognition images)<br>**Versioning:** Disabled<br>**Public Access:** Blocked | `aws s3 ls s3://orders-backup-nofar-2024` |
| **Rekognition** | Service: Image Analysis | AI service for analyzing product images. Detects labels (objects) and text (OCR). Freestyle enhancement chosen for its powerful ML capabilities. | **Features Used:**<br>- detect_labels (object detection)<br>- detect_text (OCR)<br>**Min Confidence:** 70% for labels, 80% for text<br>**Max Labels:** 10 | `aws rekognition describe-projects` |
| **IAM** | Role: `LabRole` | Pre-configured role in Learner Lab with necessary permissions for all services. Used by all Lambda functions. | **Permissions:** Full access to DynamoDB, S3, SNS, Rekognition, Lambda, CloudWatch Logs<br>**Note:** Pre-existing in Learner Lab, not created by student | `aws iam get-role --role-name LabRole` |
| **CloudWatch Logs** | Log Groups: Multiple | Automatic logging for all Lambda functions. Used for debugging and monitoring. | **Log Groups:** One per Lambda function<br>**Retention:** Default (never expire)<br>**Usage:** Debugging, monitoring, error tracking | `aws logs describe-log-groups` |

## Additional Notes:

### Lambda Layer:
- **Name:** reportlab-layer-py312
- **Purpose:** Provides reportlab library for PDF generation
- **Build Method:** Docker container with Python 3.12 base image
- **Size:** ~9.7MB
- **Reason:** Required for GeneratePDFReport function to create PDF files

### Event-Driven Architecture:
- DeleteOrder triggers NotifyDeletion and BackupOrder asynchronously through direct Lambda invocation
- This ensures the deletion response is immediate and not blocked by notification/backup processes
- EventBridge Rules were initially planned but replaced with direct invocation due to Learner Lab IAM restrictions

### API Gateway Configuration:
- **Base URL:** https://6kav3jqnbg.execute-api.us-east-1.amazonaws.com/prod
- **CORS:** Enabled on all endpoints to support web client
- **Lambda Proxy Integration:** Enabled to pass full request context to Lambda functions
- **Deployment Stage:** prod
