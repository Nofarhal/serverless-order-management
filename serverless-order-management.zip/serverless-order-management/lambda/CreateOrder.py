import json
import boto3
import uuid
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('orders')

def lambda_handler(event, context):
    try:
        print(f"Event: {json.dumps(event)}")
        
        body = json.loads(event['body'])
        
        if 'price' not in body or 'description' not in body:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'Missing required fields: price and description'})
            }
        
        price = body['price']
        description = body['description']
        
        if price <= 0:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'Price must be greater than 0'})
            }
        
        order_id = str(uuid.uuid4())
        creation_date = datetime.utcnow().isoformat()
        
        order = {
            'orderId': order_id,
            'creationDate': creation_date,
            'price': price,
            'description': description,
            'lastModifiedDate': creation_date
        }
        
        table.put_item(Item=order)
        
        print(f"Order created: {order_id}")
        
        return {
            'statusCode': 201,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Order created successfully',
                'order': order
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': f'Internal server error: {str(e)}'})
        }
