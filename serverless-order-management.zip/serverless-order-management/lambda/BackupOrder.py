import json
import boto3
from datetime import datetime

s3 = boto3.client('s3')
BUCKET_NAME = 'orders-backup-nofar-2024'

def lambda_handler(event, context):
    try:
        print(f"Event: {json.dumps(event)}")
        
        order = event['order']
        
        timestamp = datetime.utcnow().strftime('%Y%m%d-%H%M%S')
        file_name = f"deleted_orders/{order['orderId']}_{timestamp}.txt"
        
        content = f"""Order Backup - Deleted Order

Order ID: {order['orderId']}
Price: ${order['price']}
Description: {order['description']}
Creation Date: {order['creationDate']}
Deletion Date: {timestamp}

This order was automatically backed up upon deletion.
"""
        
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=file_name,
            Body=content,
            ContentType='text/plain'
        )
        
        print(f"Backup created: {file_name}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Backup created successfully'})
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': f'Internal server error: {str(e)}'})
        }
