import json
import boto3

sns = boto3.client('sns')
TOPIC_ARN = 'arn:aws:sns:us-east-1:919474847019:OrderDeletionNotifications'

def lambda_handler(event, context):
    try:
        print(f"Event: {json.dumps(event)}")
        
        body = json.loads(event['body'])
        
        if 'email' not in body:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'Missing email address'})
            }
        
        email = body['email']
        
        response = sns.list_subscriptions_by_topic(TopicArn=TOPIC_ARN)
        
        for subscription in response['Subscriptions']:
            if subscription['Endpoint'] == email and subscription['Protocol'] == 'email':
                sns.unsubscribe(SubscriptionArn=subscription['SubscriptionArn'])
                print(f"Unsubscribed: {email}")
                
                return {
                    'statusCode': 200,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({
                        'message': 'Successfully unsubscribed from notifications'
                    })
                }
        
        return {
            'statusCode': 404,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': 'Email not found in subscriptions'})
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': f'Internal server error: {str(e)}'})
        }
