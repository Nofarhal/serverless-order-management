import json
import boto3
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.units import inch
import io

s3 = boto3.client('s3')
BUCKET_NAME = 'orders-backup-nofar-2024'

def lambda_handler(event, context):
    try:
        print(f"Event: {json.dumps(event)}")
        
        response = s3.list_objects_v2(
            Bucket=BUCKET_NAME,
            Prefix='deleted_orders/'
        )
        
        if 'Contents' not in response:
            return {
                'statusCode': 404,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'No deleted orders found'})
            }
        
        orders_data = []
        for obj in response['Contents']:
            if obj['Key'].endswith('.txt'):
                file_response = s3.get_object(Bucket=BUCKET_NAME, Key=obj['Key'])
                content = file_response['Body'].read().decode('utf-8')
                orders_data.append(content)
        
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        elements = []
        
        styles = getSampleStyleSheet()
        title = Paragraph("Deleted Orders Report", styles['Title'])
        elements.append(title)
        elements.append(Spacer(1, 0.5*inch))
        
        subtitle = Paragraph(f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC", styles['Normal'])
        elements.append(subtitle)
        elements.append(Spacer(1, 0.3*inch))
        
        summary = Paragraph(f"Total Deleted Orders: {len(orders_data)}", styles['Heading2'])
        elements.append(summary)
        elements.append(Spacer(1, 0.3*inch))
        
        for i, order_content in enumerate(orders_data, 1):
            order_para = Paragraph(f"<b>Order {i}:</b>", styles['Heading3'])
            elements.append(order_para)
            
            order_text = Paragraph(order_content.replace('\n', '<br/>'), styles['Normal'])
            elements.append(order_text)
            elements.append(Spacer(1, 0.2*inch))
        
        doc.build(elements)
        
        pdf_content = buffer.getvalue()
        buffer.close()
        
        timestamp = datetime.utcnow().strftime('%Y%m%d-%H%M%S')
        pdf_key = f'reports/deleted_orders_report_{timestamp}.pdf'
        
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=pdf_key,
            Body=pdf_content,
            ContentType='application/pdf'
        )
        
        pdf_url = s3.generate_presigned_url(
            'get_object',
            Params={'Bucket': BUCKET_NAME, 'Key': pdf_key},
            ExpiresIn=3600
        )
        
        print(f"PDF report generated: {pdf_key}")
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'PDF report generated successfully',
                'pdfUrl': pdf_url
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': f'Internal server error: {str(e)}'})
        }
