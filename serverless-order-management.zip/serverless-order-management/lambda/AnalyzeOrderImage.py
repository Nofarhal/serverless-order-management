import json
import boto3
import base64
from datetime import datetime
from decimal import Decimal

s3 = boto3.client('s3')
rekognition = boto3.client('rekognition')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('orders')

BUCKET_NAME = 'orders-backup-nofar-2024'

def decimal_to_float(obj):
    if isinstance(obj, list):
        return [decimal_to_float(item) for item in obj]
    elif isinstance(obj, dict):
        return {key: decimal_to_float(value) for key, value in obj.items()}
    elif isinstance(obj, Decimal):
        return float(obj)
    else:
        return obj

def lambda_handler(event, context):
    try:
        print(f"Event: {json.dumps(event)}")
        
        if 'pathParameters' not in event or 'orderId' not in event['pathParameters']:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'Missing orderId'})
            }
        
        order_id = event['pathParameters']['orderId']
        
        body = json.loads(event['body'])
        if 'image' not in body:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'Missing image data'})
            }
        
        image_data = base64.b64decode(body['image'])
        
        timestamp = datetime.utcnow().strftime('%Y%m%d-%H%M%S')
        image_key = f'order-images/{order_id}_{timestamp}.jpg'
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=image_key,
            Body=image_data,
            ContentType='image/jpeg'
        )
        
        print(f"Image uploaded to S3: {image_key}")
        
        labels_response = rekognition.detect_labels(
            Image={
                'S3Object': {
                    'Bucket': BUCKET_NAME,
                    'Name': image_key
                }
            },
            MaxLabels=10,
            MinConfidence=70
        )
        
        labels = [
            {
                'name': label['Name'],
                'confidence': Decimal(str(round(label['Confidence'], 2)))
            }
            for label in labels_response['Labels']
        ]
        
        print(f"Labels detected: {labels}")
        
        detected_text = []
        try:
            text_response = rekognition.detect_text(
                Image={
                    'S3Object': {
                        'Bucket': BUCKET_NAME,
                        'Name': image_key
                    }
                }
            )
            
            detected_text = [
                text['DetectedText']
                for text in text_response['TextDetections']
                if text['Type'] == 'LINE' and text['Confidence'] > 80
            ]
        except Exception as text_error:
            print(f"Text detection error: {text_error}")
        
        print(f"Text detected: {detected_text}")
        
        response = table.query(
            KeyConditionExpression='orderId = :oid',
            ExpressionAttributeValues={
                ':oid': order_id
            }
        )
        
        items = response.get('Items', [])
        if not items:
            return {
                'statusCode': 404,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'Order not found'})
            }
        
        order = items[0]
        creation_date = order['creationDate']
        
        table.update_item(
            Key={
                'orderId': order_id,
                'creationDate': creation_date
            },
            UpdateExpression='SET imageUrl = :url, imageLabels = :labels, imageText = :text, imageAnalyzedAt = :time',
            ExpressionAttributeValues={
                ':url': f'https://{BUCKET_NAME}.s3.amazonaws.com/{image_key}',
                ':labels': labels,
                ':text': detected_text,
                ':time': timestamp
            }
        )
        
        print(f"Order updated with image analysis")
        
        labels_json = decimal_to_float(labels)
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Image analyzed successfully',
                'orderId': order_id,
                'imageUrl': f'https://{BUCKET_NAME}.s3.amazonaws.com/{image_key}',
                'analysis': {
                    'labels': labels_json,
                    'detectedText': detected_text
                }
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': f'Internal server error: {str(e)}'})
        }
