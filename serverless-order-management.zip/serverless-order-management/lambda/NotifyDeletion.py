import json
import boto3

sns = boto3.client('sns')
TOPIC_ARN = 'arn:aws:sns:us-east-1:919474847019:OrderDeletionNotifications'

def lambda_handler(event, context):
    try:
        print(f"Event: {json.dumps(event)}")
        
        order = event['order']
        
        message = f"""
Order Deletion Notification

An order has been deleted from the system.

Order Details:
- Order ID: {order['orderId']}
- Price: ${order['price']}
- Description: {order['description']}
- Created: {order['creationDate']}

This is an automated notification from the Order Management System.
"""
        
        response = sns.publish(
            TopicArn=TOPIC_ARN,
            Subject='Order Deleted',
            Message=message
        )
        
        print(f"Notification sent for order: {order['orderId']}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Notification sent successfully'})
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': f'Internal server error: {str(e)}'})
        }
